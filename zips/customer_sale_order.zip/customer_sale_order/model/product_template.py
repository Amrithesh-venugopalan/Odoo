# -*- coding: utf-8 -*-

from odoo import fields, models, api


class ProductTemplate(models.Model):
    _inherit = "product.template"

    total_count = fields.Integer(string='Quantities Sold', compute="_compute_total_count")

    def _compute_total_count(self):
        for rec in self:
            rec.total_count = 0
            count = 0
            for sale in self.env['sale.order'].search([]):
                for product in sale.order_line:
                    if product.product_template_id.id == rec.id:
                        count += product.product_uom_qty
            rec.total_count = count

    @api.onchange('list_price')
    def change_draft_sale_order_price(self):
        for rec in self.env['sale.order'].search([('state','=','draft')]):
            if self.id in rec.order_line.mapped('product_template_id.id'):
                print('hello')
