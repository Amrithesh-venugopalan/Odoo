from odoo.http import request, Controller, route


class PropertyManagementController(Controller):

    @route('/property_management', auth='public', website=True)
    def property_management_form(self, **kwargs):
        rent_lease_record = request.env['property.rent.lease.management'].search(
            [('create_uid.id', '=', request.session.uid)])
        values = {
            'records': rent_lease_record
        }
        return request.render('property_management.property_management_template', values)

    @route('/property_management/create/modal', type='http', csrf=False, auth='public', website=True)
    def show_modal(self, **post):
        return request.redirect('/property_management')
