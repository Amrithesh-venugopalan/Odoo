# -*- coding: utf-8 -*-

{
    'name': "Property Management",
    'version': '17.0.0.1.0',
    'depends': ['base', 'web', 'mail', 'account'],
    'author': "Amrithesh",
    'category': 'Category',
    'description': """
    Property Management App
    """,

    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'wizard/rent_lease_wizard.xml',
        'data/order_sequence.xml',
        'data/property_demo_data.xml',
        'data/email_template.xml',
        'data/scheduled_action_mail.xml',
        'data/payment_remainder_email_template.xml',
        'report/property_management_reports.xml',
        'report/property_management_templates.xml',
        'view/property_management_properties_view.xml',
        'view/inherited_partner_form_view.xml',
        'view/property_rent_lease_management_view.xml',
        'view/property_management_tags_view.xml',
        'view/property_management_website.xml',
        'view/property_management_website_menu.xml',
        'view/property_management_menu.xml',
    ],
    'assets': {
        'web.assets_backend': [
            'property_management/static/src/js/action_manager.js'
        ],
        'web.assets_frontend': [
            'property_management/static/css/property_management.css',
        ]

    },

    'application': True,
    'installable': True,
    'auto_install': False,
}
