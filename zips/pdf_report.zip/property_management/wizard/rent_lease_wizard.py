# -*- coding: utf-8 -*-

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
from datetime import date


class RentLeaseWizard(models.TransientModel):
    """class for defining rent lease wizard for printing reports"""

    _name = 'rent.lease.wizard'
    _description = 'Rent Lease Wizard'

    name = fields.Char(string="Name")
    from_date = fields.Date(string="From Date")
    to_date = fields.Date(string="To Date")
    state = fields.Selection(string='Agreement State',
                             selection=[('draft', 'Draft'), ('confirmed', 'Confirmed'),
                                        ('closed', 'Closed'),
                                        ('returned', 'Returned'), ('expired', 'Expired')
                                        ])
    tenant_id = fields.Many2one('res.partner', string="Tenant")
    owner_id = fields.Many2one('res.partner', string="Owner")
    type = fields.Selection(selection=[('rent', 'Rent'), ('lease', 'Lease')])
    property_id = fields.Many2one('property.management.properties')

    @api.constrains('to_date')
    def check_from_date(self):
        """function to add validation for from and to dates"""
        for rec in self:
            if rec.from_date and rec.to_date and rec.from_date > rec.to_date:
                raise ValidationError(_("Invalid Dates"))

    def action_print_xlsx_report(self):
        """function for printing xlsx report"""
        return

    def action_print_pdf_report(self):
        """function for printing pdf report"""
        data = {
            'model': 'rent.lease.wizard',
            'name': self.name,
            'from_date': self.from_date,
            'to_date': self.to_date,
            'state': self.state,
            'tenant': self.tenant_id.name,
            'owner': self.owner_id.name,
            'type': self.type,
            'property': self.property_id.name,
            'date': date.today()
        }
        return self.env.ref('property_management.action_report_property_rent_lease_management').report_action(None,
                                                                                                              data=data)
