# -*- coding: utf-8 -*-

from . import rent_lease_wizard
