/** @odoo-module **/

import { jsonrpc } from "@web/core/network/rpc_service";

$('.property-check-box').change(function(e){
    e.target.setAttribute('data-checked',e.target.getAttribute('data-checked')=='false'?'true':'false')
    $('.rent_lease_amount').prop('value',calculateRentLeaseAmount())
});

function calculateRentLeaseAmount() {
  let agreementType=$(".agreement_type").val()
    let sum=0
    let find_attr=''
    if (agreementType=='rent') {
        find_attr='data-rent'
    } else if (agreementType=='lease') {
        find_attr='data-lease'
    }
    let all_records=$('[data-checked = "true"]')
    if (find_attr && all_records['length']>0){
            for (let i=0;i<all_records['length'];i++){
        sum+=parseInt(all_records[i].getAttribute(find_attr))
        }
    }
   return sum
}

$('.agreement_type').change(function(e){
    $('.rent_lease_amount').prop('value',calculateRentLeaseAmount())
    }
)
$('.new-customer-btn').click(function(){
    console.log('trying')
    $('#myModal').modal('show')
})
