# -*- coding: utf-8 -*-

from . import property_management_properties
from . import property_rent_lease_management
from . import property_management_tags
from . import account_move
from . import res_partner
